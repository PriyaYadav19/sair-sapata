import React, { Component } from 'react';
import Grid from "@material-ui/core/Grid";
import MailOutlineIcon from "@material-ui/icons/MailOutline";
import foot from "../images/subscribe-banner.jpg";
import { Repeat } from '@material-ui/icons';

const Footer = () => {
  return (

    <Grid
    container
     md={12} xs={12}
    style={{
      backgroundSize: "cover",
      backgroundPosition: "center",
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      position: 'relative',
      padding: 120,
      backgroundImage: `url(${foot})`,
      backgroundRepeat :  'no-repeat' ,
      zIndex: 1,
      backgroundColor:' rgba(0 0 0 0.8) !important',

    }}
  >
</Grid>
 );
};

export default Footer;
