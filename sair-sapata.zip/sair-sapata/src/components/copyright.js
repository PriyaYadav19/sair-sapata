import React, { Component } from 'react';
import Grid from "@material-ui/core/Grid";
import MailOutlineIcon from "@material-ui/icons/MailOutline";
import logo from "../images/logo.png";
import { Repeat } from '@material-ui/icons';

const Copyright = () => {
  return (

    <Grid
    container
     md={3}  xs={12}
    style={{
      backgroundSize: "cover",
      backgroundPosition: "center",
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      position: 'relative',
      padding: 120,
      backgroundImage: `url(${logo})`,
      width:150,
      marginLeft:29,
      backgroundRepeat :  'no-repeat' ,
      zIndex: 1,
      height:20,
      backgroundColor:' rgba(0 0 0 0.8) !important',
marginTop:20
    }}>     
    
          
     <Grid
    container
    item
    md={8}
    xs={12}  style={{ marginTop: 0,marginLeft:120 }}
    >
   
</Grid>



<Grid container >
<Grid item md={8} xs={12}  style={{marginLeft:230 ,marginRight:20, marginTop:-250}}> 
<div class="col-md-3 col-sm-12">
    <div class="single-footer-item">
        <h2 class="special-offer-text"style={{color:'#9CD773'}}>link</h2>
        <div class="single-footer-txt">
            <p><a href="#">home</a></p>
            <p><a href="#">destination</a></p>
            <p><a href="#">spacial packages</a></p>
            <p><a href="#">special offers</a></p>
            <p><a href="#">blog</a></p>
            <p><a href="#">contacts</a></p>
        </div>
    </div>
</div>
   </Grid>
</Grid>


<Grid container style={{marginTop:-250}}>
<Grid item md={10}  xs={12} style={{marginLeft:450}}>

<div class="single-footer-item">
								<h2 class="special-offer-text"  style={{color:'#9CD773'}}> popular destination</h2>
								<div class="single-footer-txt">
									<p><a href="#">china</a></p>
									<p><a href="#">venezuela</a></p>
									<p><a href="#">brazil</a></p>
									<p><a href="#">australia</a></p>
									<p><a href="#">london</a></p>
								</div>
							</div>

</Grid>

</Grid>

<Grid container  >
    <Grid item md={3} xs={12} style={{marginLeft:760 ,marginTop:-50}}>
    <div class="single-footer-item text-center">
								<h2 class="text-left special-offer-text" style={{color:'#9CD773'}}>contacts</h2>
								<div class="single-footer-txt text-left">
									<p><a href="tel:123456789">+91-2345967821</a></p>
									<p class="foot-email"><a href="mailto:info@bookmyshow.com">info@bookmyshow.com</a></p>
									<p class="text-white">ALTER TECH PRIVATE LIMITED ,PUNE</p>
								</div>
							</div>
    </Grid>
    </Grid>



    <Grid item md={12} xs={12}  style={{marginLeft:20 ,marginRight:20, marginTop:-50}}> 
    
    <p>© 2017 <a href="#">BookMyFly</a>. All Right Reserved</p>

    </Grid>

</Grid>





 );
};

export default Copyright;
