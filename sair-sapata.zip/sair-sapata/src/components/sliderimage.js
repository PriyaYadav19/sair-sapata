import React from "react";
import "react-responsive-carousel/lib/styles/carousel.min.css";
import { Carousel } from "react-responsive-carousel";
import img1 from "../images/world2.jpg";
import img2 from "../images/paris.jpg";
import img3 from "../images/1.JPEG";
import Typography from "@material-ui/core/Typography";
import "./sliderimage.css";
import { Grid } from "@material-ui/core";
//import { AutoRotatingCarousel } from 'material-auto-rotating-carousel';

export default function CarouselComponent() {
  return (
    <Grid container style={{ backgroundColor: "#F9F9F9" , marginTop:20  }}>
            <Grid item  xs={12}  style={{marginTop:280}} ></Grid>

      <Grid item md={12} xs={12}   >
        <Typography
          variant="h5"
          component="h6"
          style={{
            color: "black",
            marginLeft: 650,
            marginTop: -180,
            fontWeight: "bold",
          }}
        >
          Who loves us
        </Typography>
        <Typography
          variant="p"
          component="p"
          style={{ color: "black",  marginLeft:20,fontSize:16 }}
          
        >
          <br></br>
          Look at what our users says
        </Typography>

        </Grid>

        <br></br>

        <Grid item md={12} xs={12}>

        <div class="carousel-wrapper slider  ">
          <Carousel infiniteLoop useKeyboardArrows autoPlay showThumbs={false}>
            
            <div>
              <img
                src={img1}
                alt="image1"
                style={{
                  height: 150,
                  width: 150,
                  borderRadius: 100,
                  marginTop: 80,
                }}
              />
              <br></br>
              <br></br>

              <Typography variant="p" component="p" style={{ color: "black" }}>
                "Could I... BE any more happy with this company?"
                <br></br>
                <br></br>
                Miss Random Girls, Blogger
              </Typography>
            </div>
            <div>
              <img
                src={img2}
                alt="world"
                style={{
                  height: 150,
                  width: 150,
                  borderRadius: 100,
                  marginTop: 80,
                }}
              />
              <br></br>
              <br></br>

              <Typography variant="p" component="p" style={{ color: "black" }}>
                "cafe coffee day is the best. I am so happy with the result!"
                <br></br>
                <br></br>
                Pushkar enterprises
              </Typography>
            </div>
            <div>
              <img
                src={img3}
                alt="sir"
                style={{
                  height: 150,
                  width: 150,
                  borderRadius: 100,
                  marginTop: 80,
                }}
              />
              <br></br>
              <br></br>

              <Typography variant="p" component="p" style={{ color: "black" }}>
                "One word... WOW!!"
                <br></br>
                <br></br>
              sanika , Traveler<br></br>
              </Typography>
            </div>
          </Carousel>
        </div>
    </Grid>
    </Grid>
  );
}
