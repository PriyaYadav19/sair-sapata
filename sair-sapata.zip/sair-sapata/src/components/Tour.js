import { Avatar, Grid } from "@material-ui/core";
import React, { Component, Image, Form } from "react";
import img1 from "../images/world2.jpg";
import img2 from "../images/hotels.jpg";
import img3 from "../images/trains.jpg";
import img4 from "../images/moneytransfer.jpg";
import img5 from "../images/buses.jpg";
import img6 from "../images/cab.jpg";
import Typography from "@material-ui/core/Typography";
import "./tour.css";
import { ScatterPlot } from "@material-ui/icons";

const Tour = () => {
  return (
    <Grid container style={{ height: 690 ,background:'white' }}>
      <Grid item lg={6} sm={6} xs={12}>
        {" "}
        <h6 style={{ color: "black", height: 50 ,}}></h6>
      </Grid>
      <Grid item md={0} xs={0}></Grid>

      <Grid   item  md={12}  xs={12}>
        {" "}
        <Typography
          variant="h5"
          component="h5"
          style={{
            fontWeight: "bold",
            fontSize:30,
            color: '#565F86',
            alignItems:'center',
            marginTop: 140,
            marginLeft: 600,

          }}
        >
          BookMyFly - Offers
        </Typography>
        <Typography
          variant="p"
          component="p"
          style={{ marginTop: 30, marginLeft: 10 ,color:'#BDCCDE'}}
        >
          Best choices for you
        </Typography>
      </Grid>
      <Grid item md={0} sm={0} xs={0}></Grid>

      <Grid item lg={2} sm={8} xs={12}>
        <Grid  container item lg={0} sm={0} xs={12}  justify="center"
              alignItems="center"  >
          {" "}
          <div>
            <img
              alt="sair-sapata logo"
              src={img1}
              style={{
                width: 120,
                borderRadius: 100,
                height: 120,
                marginTop:98,
               border: "1px solid rgba(0, 0, 0, 0.05)",
              }}
            />
            <Typography
              variant="h6"
              component="h6"
              style={{ marginTop: 30, marginLeft: 30, fontWeight: "bold" }}
            >
              Jaipur{" "}
            </Typography>
          </div>
        </Grid>
      </Grid>
      <Grid  container item lg={2} sm={6} xs={12}  justify="center"
              alignItems="center">
        {" "}
        <div>
          <img
            alt="sair-sapata logo"
            src={img2}
            style={{
              width: 120,
              borderRadius: 100,
              height: 120,
            }}
          />
          <Typography
            variant="h6"
            component="h6"
            style={{ marginTop: 30, marginLeft: 20, fontWeight: "bold" }}
          >
            West Bengal
          </Typography>
        </div>
      </Grid>

      <Grid  container item lg={2} sm={6} xs={12} justify="center"
              alignItems="center" >
        {" "}
        <div>
          <img
            alt="sair-sapata logo"
            src={img3}
            style={{
              width: 120,
              borderRadius: 100,
              height: 120,
            }}
          />
          <Typography
            variant="h6"
            component="h6"
            style={{
              marginTop: 30,
              marginLeft: 30,
              fontWeight: "bold",
            }}
          >
            Paris
          </Typography>
        </div>
      </Grid>

      <Grid container item lg={2} sm={6} xs={12}  justify="center"
              alignItems="center" >
        {" "}
        <div>
          <img
            alt="sair-sapata logo"
            src={img4}
            style={{
              width: 120,
              borderRadius: 100,
              height: 120,
            }}
          />
          <Typography
            variant="h6"
            component="h6"
            style={{
              marginTop: 30,
              marginLeft: 20,
              fontWeight: "bold",
            }}
          >
            Montaray
          </Typography>
        </div>
      </Grid>
      <Grid  container item lg={2} sm={6} xs={12} justify="center"
              alignItems="center" >
        {" "}
        <div>
          <img
            alt="sair-sapata logo"
            src={img5}
            style={{
              width: 120,
              borderRadius: 100,
              height: 120,
            }}
          />
          <Typography
            variant="h6"
            component="h6"
            style={{ marginTop: 30, marginLeft: 20, fontWeight: "bold" }}
          >
            California{" "}
          </Typography>
        </div>
      </Grid>
      <Grid  container item lg={2} sm={6} xs={12}  justify="center"
              alignItems="center" >
        {" "}
        <div>
          <img
            alt="sair-sapata logo"
            src={img6}
            style={{
              width: 120,
              borderRadius: 100,
              height: 120,
            }}
          />
          <Typography
            variant="h6"
            component="h6"
            style={{ marginTop: 30, marginLeft: 20, fontWeight: "bold" }}
          >
            Morgan Hills{" "}
          </Typography>
        </div>
      </Grid>
    </Grid>
  );
};

export default Tour;
