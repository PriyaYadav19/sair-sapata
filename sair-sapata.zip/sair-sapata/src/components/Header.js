import React, { Component, Image, Form } from "react";
import Grid from "@material-ui/core/Grid";
import MailOutlineIcon from "@material-ui/icons/MailOutline";
import logo from "../images/logo.png";
const Header = () => {
  return (
    <Grid container style={{ background: "white", height: 100, marginLeft: 0 }}>
      <Grid
        item
        container
        md={3}
        xs={12}
        justify="center"
        alignItems="center"
      ><img width={80} src={logo}></img></Grid>

      <Grid item md={2} xs={0}></Grid> 
      <Grid
        container
        item
        md={3}
        xs={12}
        justify="center"
        alignItems="center"
        style={{ color: "black" }}
      >
        <MailOutlineIcon /> Support Email: support@ALTER.com
      </Grid>
      <Grid
        container
        item
        md={3}
        xs={12}
        justify="center"
        alignItems="center"
        style={{ color: "black" }}
      >
        {" "}
        24x7 Helpdesk: (+91) 65743532 / 34 / 34{" "}
      </Grid>
      <Grid item md={1} xs={0}></Grid>
    </Grid>
  );
};

export default Header;
