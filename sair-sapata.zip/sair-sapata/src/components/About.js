import React, { Fragment } from "react";
import Grid from "@material-ui/core/Grid";
import img3 from "../images/why-we-1.png";
import img2 from "../images/banner1.jpg";

import Typography from "@material-ui/core/Typography";
import Avatar from "@material-ui/core/Avatar";
import logo from "../images/login-logo.png";
const AboutUs = () => {
  return (
    <>
      <Grid
        container
        xs={12}
        style={{
          backgroundImage: `url(${img2})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          display: 'flex',
          justifyContent: 'center',
           alignItems: 'center',
           position: 'relative'
    
   
        }}
      >
        <Grid item md={6} xs={10} style={{ marginTop: 0 }}>
          <Grid container>
            <Grid
              container
              item
              md={12}
              xs={12}
             
              style={{ marginTop: 30,marginLeft:120 }}
            >
              <Typography
                variant="h5"
                component="p"
                style={{ color: "white", fontWeight: 800 ,zIndex:1}}
              >
                Want to explore beauty of world,
                <br></br> search flights
              </Typography>
            </Grid>
          </Grid>
        </Grid>
        <Grid item md={6} xs={12} style={{ marginTop: 100 }}>
          <Grid container>
            <Grid item md={10} xs={12}>
              <div
                style={{
                  background: "white",
                  height: 500,
                  borderTopLeftRadius: 35,
                  borderTopRightRadius: 35,
            
                }}
              >
                {" "}
              </div>
            </Grid>

            <Grid item md={2}></Grid>
          </Grid>
        </Grid>
      </Grid>

      <Grid container style={{ marginTop: 50 }}>
        <Grid item md={0} xs={0}></Grid>

        <Grid  container  item  md={6} xs={12} style={{ paddingLeft: 50 }}>
          <Typography variant="h4" component="h6">
            Why, Sair-Sapaata?{" "}
          </Typography>

          <Typography variant="p" component="p" style={{ marginTop: 20  , paddingLeft:20 ,marginRight:20 ,justify:'center',alignItems:'center'}}>
             "This is dummy text, we'll update later". Flight attendant's job
                              gives you an 
            <br></br>
           opportunity to interact with different background
            people. Certainly, there will always be the crazy ones, but most of
            the passengers are interesting â€“ each with their own story and
            destination. As well as it is a great chance to learn different
            cultures and customs.
            <br></br>
            <br></br>
            Flight attendant's job gives you an opportunity to interact with
            different background people. Certainly, there will always be the
            crazy ones, but most of the passengers are interesting â€“ each with
            their own story and destination. As well as it is a great chance to
            learn different cultures and customs.
          </Typography>
        </Grid>

        <Grid item md={6} xs={12}>
          <Grid container>
            <Grid item md={6} xs={12}>
              <img
                alt="sair-sapata logo"
                src={img3}
                style={{
                  width: 600,
                  borderBottomLeftRadius: 15,
                  borderBottomRightRadius: 15,
                  height: "auto",
                  marginLeft: 50,
                }}
              />
            </Grid>

            <Grid item md={1} xs={1}></Grid>
          </Grid>
        </Grid>
      </Grid>
    </>
  );
};

export default AboutUs;
