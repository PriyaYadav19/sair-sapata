import './App.css';
import Aboutus from './components/About';
import Tour from './components/Tour';

import CarouselComponent from './components/sliderimage'
import Slider  from './components/sliderimage';
import Header from './components/Header';
import Footer from './components/Footer';
import Copyright from './components/copyright';

function App() {
  return (
    < >
      <Header/>
       <Aboutus/>

       <Tour/>
       <CarouselComponent/>
       <Footer/>
       <Copyright/>

       
      {/* <Slider/>  */}
    </>
  );
}

export default App;
